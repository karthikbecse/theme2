Ext.define('Viewer.view.panel.BigFormPanel', {
    extend: 'Viewer.view.panel.FormPanel',
    xtype: 'c-preview-formpanel-big',
    defaults: {
        labelWidth: 140
    }
});