/**
 * Created by dan on 12/1/16.
 */
Ext.define('Viewer.view.ExampleComponentFactory', {
    requires: [
        'Ext.data.proxy.Ajax',
        'Ext.dataview.List',
        'Ext.field.Checkbox',
        'Ext.field.DatePicker',
        'Ext.field.Radio',
        'Ext.field.Select',
        'Ext.field.Slider',
        'Ext.field.Spinner',
        'Ext.field.Text',
        'Ext.field.TextArea',
        'Ext.field.Toggle',
        'Ext.form.Panel',
        'Ext.grid.Grid',
        'Ext.grid.cell.Cell',
        'Ext.grid.column.Number',
        'Ext.grid.plugin.ColumnResizing',
        'Ext.grid.plugin.PagingToolbar',
        'Ext.grid.plugin.SummaryRow',
        'Ext.layout.Fit',
        'Ext.layout.VBox',
        'Ext.list.Tree',
        'Ext.slider.Slider',
        'Ext.slider.Thumb',
        'Ext.tab.Panel',
        'Viewer.DummyText',
        'Viewer.model.RowExpanderModel',
        'Viewer.view.list.ListController',
        'Viewer.view.list.ListModel',
        'Viewer.view.tree.TreeModel'
    ],

    singleton: true,

    create: function(xtype, uiName) {
        var funcName = this._getFuncName(xtype);
        if(this[funcName]) {
            return this[funcName](uiName);
        }
    },

    createGrid: function(uiName) {
        var config = {
            cls: 'c-preview-root',
            layout: 'fit',
            grouped: true,
            store: {
                model: 'Viewer.model.RowExpanderModel',
                autoLoad: true,
                grouper: {
                    groupFn: function(record) {
                        return record.get('name')[0];
                    }
                },
                proxy: {
                    type: 'ajax',
                    url: 'data/row-expander-data.json',
                    reader: {
                        rootProperty: 'results'
                    }
                }
            },
            plugins: [{
                type: 'gridpagingtoolbar'
            }, {
                type: 'gridsummaryrow'
            }, {
                type: 'gridcolumnresizing'
            }],
            columns: [{
                text: 'Name',
                dataIndex: 'name',
                flex: 3,
                summaryType: 'count',
                resizable: true,
                ui: uiName,
                summaryRenderer: function (value) {
                    return value + ' Companies';
                },
                cell: {
                    xtype: 'gridcell',
                    ui: uiName
                }
            },{
                text: 'Price',
                dataIndex: 'price',
                flex: 1,
                minWidth: 80,
                summaryType: 'average',
                xtype: 'numbercolumn',
                resizable: true,
                format: '0.00',
                ui: uiName,
                cell: {
                    xtype: 'gridcell',
                    ui: uiName
                }
            }],

            itemConfig: {
                ui: uiName,
                header: {
                    ui: uiName
                },
                headerContainer: {
                    ui: uiName
                },
                body: {
                    tpl: new Ext.XTemplate(
                        '<p><b>Change:</b> {change:this.formatChange}</p>',
                        {
                            formatChange: function(v){
                                return '<span>' + Ext.util.Format.usMoney(v) + '</span>';
                            }
                        }
                    )
                }
            }
        };

        // 6.0 Modern, checkcolumn and RowExpander do not exist.
        if(Ext.grid.cell && Ext.grid.cell.Check && Ext.grid.column && Ext.grid.column.Check) {
            config.columns.push({
                xtype: 'checkcolumn',
                dataIndex: "checked",
                width: 50,
                headerCheckbox: true,
                ui: uiName,
                cell: {
                    xtype: 'checkcell',
                    ui: uiName
                }
            });
        }
        if(Ext.grid.plugin.RowExpander) {
            config.plugins.push({
                type: 'rowexpander'
            });
        }

        return Ext.create('Ext.grid.Grid', config);
    },

    createButton: function(uiName) {
        return Ext.create('Ext.Panel', {
            cls: 'c-preview-root',
            layout: {
                type : 'vbox',
                align: 'center'
            },

            bodyPadding: 20,

            defaults: {
                xtype: 'button',
                margin : '0 0 20 0',
                ui: uiName
            },

            items : [
                {
                    text: 'Button'
                },
                {
                    text: 'With an Icon',
                    iconCls: 'x-fa fa-home'
                },
                {
                    text: 'With a Badge',
                    badgeText: '42'
                },
                {
                    text: 'Disabled',
                    iconCls: 'x-fa fa-cog',
                    disabled: true
                }
            ]
        })
    },

    createFieldsCheckbox: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',
            layout: 'vbox',

            defaults: {
                labelAlign: 'left',
                labelWidth: 100,
                ui: uiName
            },

            bodyPadding: 10,

            items: [{
                xtype: 'checkboxfield',
                checked: true,
                label: 'Checked'
            }, {
                xtype: 'checkboxfield',
                label: 'Unchecked'
            }]
        });
    },

    createFieldsDate: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',

            defaults: {
                labelAlign: 'left',
                labelWidth: 100
            },

            bodyPadding: 10,

            items: [{
                xtype: 'datepickerfield',
                value: new Date(),
                label : 'Date',
                triggers: {
                    expand: {
                        ui: uiName,
                    }
                }
            }]
        })
    },

    createList: function(uiName) {
        return Ext.create('Ext.Panel', {
            cls: 'c-preview-root',
            layout: 'fit',

            viewModel: {
                type: 'list'
            },

            controller: 'list',

            items: [{
                docked: 'top',
                xtype: 'toolbar',
                items: [{
                    xtype: 'button',
                    text: 'Empty List',
                    handler: 'filterList',
                    scope: 'controller'
                }]
            }, {
                xtype: 'list',
                ui: uiName,
                bind: { store: '{states}' },
                itemTpl: '{description}',
                indexBar: {
                    ui: uiName
                },
                grouped: true,
                title: 'List',
                pinHeaders: true,
                emptyText: 'This list is empty',
                striped: true,
                itemConfig: {
                    ui: uiName,
                    header: {
                        ui: uiName
                    }
                },
                onItemDisclosure: function(record) {
                    Ext.Msg.alert(record.get('description'), record.get('country'), Ext.emptyFn);
                }
            }],
        });
    },

    createPanel: function(uiName) {
        return Ext.create('Ext.Panel', {
            cls: 'c-preview-root',

            flex: 1,
            title: 'Panel',
            html: Viewer.DummyText.mediumText,
            margin: 10,
            border: true,
            iconCls: 'x-fa fa-globe',

            tools: [
                { type:'pin' },
                { type:'refresh' },
                { type:'search' },
                { type:'save' }
            ],

            ui: uiName
        });
    },

    createFieldsRadio: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',
            layout: 'vbox',

            defaults: {
                labelAlign: 'left',
                labelWidth: 100,
                ui: uiName
            },

            bodyPadding: 10,

            items: [{
                xtype: 'radiofield',
                label : 'Checked',
                checked: true,
                name: 'radio'
            },  {
                xtype: 'radiofield',
                label : 'Unchecked',
                name: 'radio'
            }]
        })
    },

    createSelectfield: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',
            bodyPadding: 10,

            items: [{
                xtype: 'selectfield',
                label: 'Select',
                triggers: {
                    expand: {
                        ui: uiName,
                    }
                },
                options: [{
                    text: 'First Option',
                    value: 'first'
                },
                {
                    text: 'Second Option',
                    value: 'second'
                },
                {
                    text: 'Third Option',
                    value: 'third'
                }]
            }]
        });
    },

    createSliderfield: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',

            bodyPadding: 10,

            defaults: {
                minValue: 0,
                value: 50,
                maxValue: 100,
                component: {
                    xtype: 'slider',
                    ui: uiName,
                    thumbDefaults: {
                        xtype: 'thumb',
                        ui: uiName,
                        draggable: {
                            translatable: {
                                easingX: {
                                    duration: 300,
                                    type: 'ease-out'
                                }
                            }
                        }
                    }
                }
            },

            items: [{
                xtype: 'sliderfield',
                label: 'Enabled'
            }, {
                xtype: 'sliderfield',
                label: 'Disabled',
                disabled: true
            }]
        })
    },

    createSpinnerfield: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',
            bodyPadding: 10,
            items: [{
                xtype: 'spinnerfield',
                label: 'Spinner',
                minValue: 0,
                maxValue: 100,
                stepValue: 1,
                triggers: {
                    spinup: {
                        ui: uiName
                    },
                    spindown: {
                        ui: uiName
                    }
                }
            }]
        })
    },

    createTabpanel: function(uiName) {
        return Ext.create('Ext.tab.Panel', {
            cls: 'c-preview-root',

            activeTab: 0,
            tabBar: {
                layout: {
                    pack : 'center',
                    align: 'center'
                },
                docked: 'bottom',
                defaults: {
                    iconAlign: 'top'
                },
                ui: uiName
            },
            defaults: {
                scrollable: true
            },
            items: [
                {
                    title: 'Plain Tab',
                    padding: 10,
                    cls: 'card',
                    html: Viewer.DummyText.mediumText,
                    iconCls: 'x-fa fa-info-circle'
                },
                {
                    title: 'With Badge',
                    padding: 10,
                    html: Viewer.DummyText.mediumText,
                    cls: 'card',
                    iconCls: 'x-fa fa-star',
                    badgeText: '4'
                },
                {
                    title: 'Disabled',
                    padding: 10,
                    html: 'Disabled',
                    cls: 'card',
                    iconCls: 'x-fa fa-lock',
                    disabled: true
                }
            ]
        });
    },

    createFieldsText: function(uiName) {
        return Ext.create('Ext.Container', {
            cls: 'c-preview-root',

            padding: 10,

            layout: {
                type: 'vbox',
                align: 'stretch'
            },

            defaults: {
                labelAlign: 'left',
                labelWidth: 100,
                clearIcon: true,
                ui: uiName
            },

            bodyPadding: 10,

            items: [{
                xtype: 'textfield',
                label : 'Text',
                value: 'value'
            }, {
                xtype: 'textfield',
                label : 'Empty',
                placeHolder: 'placeholder'
            }, {
                xtype: 'textfield',
                label: 'Disabled',
                value: 'Disabled',
                disabled: true
            }, {
                xtype: 'textareafield',
                label : 'Text Area',
                placeHolder: 'enter long text...',
                flex: 1,
                value: Viewer.DummyText.mediumText
            }]
        })
    },

    createTogglefield: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',

            bodyPadding: 10,

            defaults: {
                xtype: 'togglefield',
                labelWidth: 100,
                ui: uiName,
                component: {
                    xtype: 'toggleslider',
                    ui: uiName
                }
            },

            items: [{
                label: 'On',
                value: true
            }, {
                label: 'Off'
            }, {
                label: 'Disabled',
                disabled: true,
                value: true
            }]
        })
    },

    createToolbar: function(uiName) {
        return Ext.create('Ext.Panel', {
            cls: 'c-preview-root',

            items: [{
                xtype: 'toolbar',
                ui: uiName,
                title: 'Horizontal',
                docked: 'top',

                items: [{
                    text: 'One',
                    ui: 'action'
                }, {
                    text: 'Two',
                    ui: 'action'
                }, {
                    xtype: 'spacer'
                }, {
                    text: 'Forward',
                    ui: 'forward'
                }]
            }, {
                xtype: 'toolbar',
                ui: uiName,
                title: 'Vertical',
                docked: 'left',

                items: [{
                    text: 'One',
                    ui: 'action'
                }, {
                    text: 'Two',
                    ui: 'action'
                }, {
                    xtype: 'spacer'
                }, {
                    text: 'Forward',
                    ui: 'forward'
                }]
            }]
        });
    },

    createTree: function(uiName) {
        var treeList = Ext.create({
            xtype: 'treelist',
            ui: uiName,
            viewModel: 'tree',
            flex: 1,
            bind: '{navItems}'
        });

        return Ext.create('Ext.Panel', {
            cls: 'c-preview-root',
            layout: {
                type: 'vbox',
                align: 'stretch'
            },
            items: [
                {
                    xtype: 'container',
                    layout: {
                        type: 'hbox',
                        pack: 'center'
                    },
                    items: [{
                        xtype: 'radiofield',
                        name: 'micro',
                        label: 'Full',
                        labelAlign: 'right',
                        checked: true,
                        labelWidth: 40,
                        margin: '0 15 0 0'
                    }, {
                        xtype: 'radiofield',
                        name: 'micro',
                        label: 'Micro',
                        labelWidth: 60,
                        labelAlign: 'right',
                        listeners: {
                            change: function(radio, micro) {
                                treeList.setMicro(micro);
                            }
                        }
                    }],
                }, 
                treeList
            ]
        });
    },

    createTitlebar: function(uiName) {
        return Ext.create('Ext.Panel', {
            cls: 'c-preview-root',
            items: [{
                xtype: 'titlebar',
                docked: 'top',
                title: 'Navigation',
                ui: uiName,
                items: [
                    {
                        iconCls: 'x-fa fa-home',
                        align: 'left'
                    },
                    {
                        iconCls: 'x-fa fa-plus',
                        align: 'right'
                    }
                ]
            }]
        })
    },

    createFormpanel: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',

            bodyPadding: 10,

            defaults: {
                labelWidth: 120
            },

            items: [{
                xtype: 'textfield',
                label: 'Field w/Value',
                value: 'value',
                ui: uiName
            }, {
                xtype: 'textfield',
                label: 'Empty Field',
                placeHolder: 'placeholder',
                ui: uiName
            }, {
                xtype: 'textfield',
                disabled: true,
                value: 'disabled',
                label: 'Disabled',
                ui: uiName
            }, {
                xtype: 'textfield',
                required: true,
                label: 'Required',
                ui: uiName
            }, {
                xtype: 'textfield',
                required: true,
                label: 'Invalid',
                value: 'invalid',
                component: {
                    pattern: 'valid'
                },
                ui: uiName
            }]
        })
    },

    /**
     * Gets the factory function name based on an xtype.
     *
     * Example:
     * 'fields-spinner' => 'createFieldsSpinner'
     * 'toolbar' => 'createToolbar'
     *
     * @param xtype
     * @returns {string}
     * @private
     */
    _getFuncName: function(xtype) {
        return 'create' + xtype.substring(0,1).toUpperCase() +
            xtype.substring(1)
                .replace(/-(.)/g, function(m, p1) { return p1.toUpperCase() });
    },
});