/**
 * Created by dan on 12/1/16.
 */
Ext.define('Viewer.view.list.ListController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.list',

    /**
     * Called when the view is created
     */
    init: function() {
        this.filtered = false;
    },

    filterList: function(btn) {
        var me = this,
            vm = me.getViewModel();

        if(me.filtered) {
            btn.setText('Empty List');
            me.filtered = false;
            vm.getStore('states').clearFilter();
        } else {
            btn.setText('Restore List');
            me.filtered = true;
            vm.getStore('states').filterBy(function() { return false; })
        }
    }
});