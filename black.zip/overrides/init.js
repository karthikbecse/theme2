Ext.namespace('Ext.theme.is')['Red'] = true;
Ext.theme.name = 'Red';